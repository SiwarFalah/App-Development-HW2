# raceHW2
Homework for apps course.

https://user-images.githubusercontent.com/18689019/209449769-1f8f906a-b716-4a0b-8e9c-f0b67972b352.mp4

