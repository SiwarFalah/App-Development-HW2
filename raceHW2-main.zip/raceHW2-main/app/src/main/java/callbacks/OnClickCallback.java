package callbacks;

public interface OnClickCallback {
    void focusOnPoint(int index);
}
