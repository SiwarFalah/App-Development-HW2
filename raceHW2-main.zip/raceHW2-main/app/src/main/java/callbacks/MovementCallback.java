package callbacks;

public interface MovementCallback {
    void moveLeft();
    void moveRight();
}
